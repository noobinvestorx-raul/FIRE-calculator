# Calculadora FIRE — @noob_Investor

## Probarlo en local

```bash
npm install
npm run dev
```

Se abre en `http://localhost:5173`.

## Desplegar en Netlify

**Opción A — Drag & drop (más rápida, sin GitHub)**
1. En local: `npm install && npm run build` (esto genera la carpeta `dist/`)
2. Ve a [app.netlify.com](https://app.netlify.com) → "Add new site" → "Deploy manually"
3. Arrastra la carpeta `dist/` entera
4. Netlify te da una URL tipo `algo-random.netlify.app` — puedes cambiarla desde Site settings → Domain management

**Opción B — Conectado a GitHub (recomendada si vas a iterar)**
1. Sube esta carpeta a un repo nuevo en GitHub
2. En Netlify: "Add new site" → "Import an existing project" → conecta el repo
3. Build command: `npm run build` · Publish directory: `dist` (ya vienen preconfigurados en `netlify.toml`)
4. Cada `git push` despliega automáticamente

## Antes de compartirlo con tu audiencia

- [ ] Configura tu cuenta de EmailJS (Service ID, Template ID, Public Key) en `src/App.jsx` y en `index.html`
- [ ] Cambia el dominio de Netlify por uno con tu marca (ej. `fire.noobinvestor.com`) desde Site settings → Domain management
- [ ] Cuando quieras cobrar de verdad, sustituye el `setTimeout` simulado en `handleUnlock` (dentro de `App.jsx`) por una sesión real de Stripe Checkout — lo ideal es una Netlify Function o Firebase Function que cree la sesión y confirme el pago por webhook antes de desbloquear el informe.

## Stack

- Vite + React
- Tailwind (vía CDN, sin build de PostCSS)
- Recharts (gráfico de evolución del patrimonio)
- Lucide React (iconos)
- EmailJS (captura de leads del informe premium)
